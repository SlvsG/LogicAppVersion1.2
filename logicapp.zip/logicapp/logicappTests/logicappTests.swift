//
//  logicappTests.swift
//  logicappTests
//
//  Created by slvs on 20/03/25.
//

import Testing

struct logicappTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
