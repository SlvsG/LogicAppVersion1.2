//
//  logicappApp.swift
//  logicapp
//
//  Created by slvs on 20/03/25.
//

import SwiftUI

@main
struct logicappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
